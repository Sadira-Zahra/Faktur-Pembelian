<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="../css/pelanggan-lihat.css"/>
    <title>pelanggan-lihat</title>
</head>
<body>
    <div class = "pelanggan-lihat">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a href="../menu.php" class="btn btn-primary"><img src= "../img/logo-bengkell.png"/></a>
            <a class="btn btn-primary" style="background-color: #00689E;">PELANGGAN</a>
            <a href="../nota/nota-lihat.php" class="btn btn-primary">NOTA</a>
            <a href="../barang/barang-lihat.php" class="btn btn-primary">BARANG</a>

            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../img/profil.png" style="width: 45px; height: 45px; margin-right: 15px; position: relative;">PROFIL
            </button>
            <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="../Index.php"><img src="../img/ganti.png" style="width: 30px; height: 40px; margin-right: 10px;">Ganti Akun</a></li>
            <li><a class="dropdown-item" href="../register.php"><img src="../img/keluar.png" style="width: 40px; height: 40px; margin-right: 10px;">Keluar</a></li>
            </ul>
        </div>   

        <a href="pelanggan-tambah.php" class="btn btn-warning" style="margin-top: 5px; margin-left: 5px;">+ TAMBAHKAN</a>

        <div class="rectangle" style="    width: 100%; text-align: center; margin-top: 5px;">
            <table class="table table-striped" style="width:100%">
                <thead class="table-primary">
                    <tr>
                        <th>NOPOL</th>
                        <th>NAMA</th>
                        <th>TIPE</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include '../koneksi.php';
                    $limit = 10; // Jumlah baris per halaman
                    $page = isset($_GET['page']) ? $_GET['page'] : 1;
                    $start = ($page - 1) * $limit;
                
                    $query = mysqli_query($conn, "SELECT * FROM pelanggan LIMIT $start, $limit");
                    while ($data=mysqli_fetch_array($query)){
                    ?>
                    <tr>
                    <td><?php echo $data['nopol'];?></td>
                    <td><?php echo $data['nama'] ;?></td>
                    <td><?php echo $data['tipe'] ;?></td>
                    <td>  
                    <a class="btn btn-success" href="pelanggan-ubah.php?nopol=<?php echo $data['nopol'];?>" role="button">Ubah</a>
                    <a class="btn btn-danger" href="pelanggan-hapus.php?nopol=<?php echo $data['nopol']; ?>" onclick="return confirm('yakin hapus?')">Hapus</a>	

                    </td>

                    </tr>
                <?php } ?>
                </tbody>
            </table>
        

            <div class="pagination">
                <?php
                $query_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM pelanggan");
                $data_total = mysqli_fetch_assoc($query_total);
                $total_pages = ceil($data_total['total'] / $limit);

                if ($page > 1) {
                    echo '<a href="?page=' . ($page - 1) . '">Back</a>';
                }

                for ($i = 1; $i <= $total_pages; $i++) {
                    if ($i == $page) {
                        echo '<a href="?page=' . $i . '" class="current">' . $i . '</a>';
                    } else {
                        echo '<a href="?page=' . $i . '">' . $i . '</a>';
                    }
                }

                if ($page < $total_pages) {
                    echo '<a href="?page=' . ($page + 1) . '">Next</a>';
                }
                ?>
            </div>

        </div>

        
    </div>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> 
   
</body>
</html>