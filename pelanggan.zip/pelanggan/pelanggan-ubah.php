<?php
    include '../koneksi.php';
    $query = mysqli_query($conn, "SELECT * FROM pelanggan WHERE nopol = '$_GET[nopol]'");
    $data = mysqli_fetch_array($query);
            
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="../css/pelanggan-ubah.css"/>
    <title>pelanggan-ubah</title>
</head>

<form action="" method="post">
    <div class = "pelanggan-ubah">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a href="../menu.php" class="btn btn-primary"><img src= "../img/logo-bengkell.png"/></a>
            <a class="btn btn-primary" style="background-color: #00689E;">PELANGGAN</a>
            <a href="../nota/nota-lihat.php" class="btn btn-primary">NOTA</a>
            <a href="../barang/barang-lihat.php" class="btn btn-primary">BARANG</a>

            <button type="button" class="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="../img/profil.png" style="width: 45px; height: 45px; margin-right: 15px; position: relative;">PROFIL
            </button>
            <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="../Index.php"><img src="../img/ganti.png" style="width: 30px; height: 40px; margin-right: 10px;">Ganti Akun</a></li>
            <li><a class="dropdown-item" href="../register.php"><img src="../img/keluar.png" style="width: 40px; height: 40px; margin-right: 10px;">Keluar</a></li>
            </ul>

        </div> 
        
        <div class="form">
            <label for="tambahNota" class="form-label" style="display: flex; flex-direction: column; align-items: center; text-align: center; font-size: large;">UBAH PELANGGAN</label>
            <hr>

            <div class="form-element">
                <label for="exampleFormControlInput1" class="form-label">NAMA</label>            
                <input type="text" name="nama" value = "<?php echo $data ['nama'] ?>" class="form-control" placeholder="Nama Lengkap">
            </div>

            <div class="form-element">
                <label for="exampleFormControlInput1" class="form-label">TIPE</label>
                <input type="text" name="tipe" value = "<?php echo $data ['tipe'] ?>" class="form-control"  placeholder="Tipe Mobil">
            </div>           
            
            <div class="tombol">
            <td><input class="btn btn-success" type="submit" name="proses" value="Ubah pelanggan">
            <a class="btn btn-danger" href="pelanggan-lihat.php">kembali</a> </td>
            </div>

          </div>

    </div>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">x 
</form>
</html>

<?php
if (isset($_POST['proses'])){
    include '../koneksi.php';
    $nopol = $_GET['nopol'];
    $nama = $_POST['nama'];
    $tipe = $_POST['tipe'];

    
    
    mysqli_query($conn, "UPDATE pelanggan SET nama='$nama',tipe='$tipe' WHERE nopol='$nopol'");
    header("location:pelanggan-lihat.php");
}
?>